﻿using System;
using System.Collections.Generic;
using System.Text;
public interface IWriter
{
    public void WriteLine(string text);
}

