﻿using System;
using System.Collections.Generic;
using System.Text;

interface IBender
{
    public string Name { get; }
    public int Power { get; }
}

