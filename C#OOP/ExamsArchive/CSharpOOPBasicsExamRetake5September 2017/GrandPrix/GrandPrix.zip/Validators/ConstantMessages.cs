﻿using System;
using System.Collections.Generic;
using System.Text;


public static class ConstantMessages
{
    public const string BlownTyre = "Blown Tyre";
    public const string OutOfFuel = "Out of fuel";
    public const string DriverCrash = "Crash";
}

