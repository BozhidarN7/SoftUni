﻿using System;
using System.Collections.Generic;
using System.Text;

public enum Mode
{
    Full,
    Half = 60,
    Energy
}

