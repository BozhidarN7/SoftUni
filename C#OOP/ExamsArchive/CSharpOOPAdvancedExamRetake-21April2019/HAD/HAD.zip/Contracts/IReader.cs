﻿namespace HAD.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}