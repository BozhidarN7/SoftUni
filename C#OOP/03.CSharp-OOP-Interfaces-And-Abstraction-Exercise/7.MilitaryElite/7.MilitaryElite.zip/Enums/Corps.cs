﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _7.MilitaryElite.Enums
{
    public enum Corps
    {
        Airforces,
        Marines
    }
}
