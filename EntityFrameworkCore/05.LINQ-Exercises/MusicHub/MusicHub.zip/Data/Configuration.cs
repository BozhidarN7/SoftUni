﻿namespace MusicHub.Data
{
   public static class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-7SFRFQN\SQLEXPRESS;Database=MusicHub;Integrated Security=true";
    }
}
