﻿namespace SoftJail.Data
{
   public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-7SFRFQN\SQLEXPRESS;Database=SoftJail;Trusted_Connection=True";
    }
}
