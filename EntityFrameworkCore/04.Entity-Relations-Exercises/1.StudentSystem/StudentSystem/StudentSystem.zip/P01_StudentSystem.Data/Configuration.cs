﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P01_StudentSystem.Data
{
    public static  class Configuration
    {
        public const string CONNECTION_STRING = @"Server=DESKTOP-7SFRFQN\SQLEXPRESS;Database=StudentSystem;Integrated Security=true";
    }
}
