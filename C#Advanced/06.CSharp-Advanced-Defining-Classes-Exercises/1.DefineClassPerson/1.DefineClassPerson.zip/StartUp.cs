﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Person person1 = new Person();
            person1.Age = 20;
            person1.Name = "Pesho";

            Person person2 = new Person();
            person2.Age = 20;
            person2.Name = "Pesho";

            Person person3 = new Person();
            person3.Age = 20;
            person3.Name = "Pesho";

        }
    }
}
